# AI Wedding Planner

A Streamlit-based AI wedding planning assistant powered by Google's Gemini AI.

## Developer Information
- **Name:** Abhinandan Pandey
- **Institution:** Lovely Professional University
- **Contact:** +91 9709925057

## Features
- Wedding timeline and checklist creation
- Budget planning and breakdown
- Venue suggestions
- Theme and decoration ideas
- Vendor recommendations
- Music and entertainment planning
- Catering and menu suggestions
- Additional wedding services recommendations

## Setup Instructions
1. Install the required packages:
   ```bash
   pip install -r requirements.txt
   ```

2. Create a `.env` file with your Gemini API key:
   ```
   GEMINI_API_KEY=your_api_key_here
   ```

3. Run the application:
   ```bash
   streamlit run app.py
   ```

## Project Structure
- `app.py`: Main application file
- `requirements.txt`: Python package dependencies
- `.env`: Environment variables and API keys

## Technologies Used
- Python
- Streamlit
- Google Gemini AI
- Python-dotenv

## Backup Information
This is a backup of the original project created on: [Current Date] 